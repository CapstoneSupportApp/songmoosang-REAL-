package com.example.supportapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.view.View;



import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {



    private BottomNavigationView bottomNavigationView;
    private FragmentManager fm;
    private FragmentTransaction ft;
    private com.example.supportapplication.FavoriteFragment favoriteFragment;
    private com.example.supportapplication.HomeFragment homeFragment;
    private com.example.supportapplication.MypageFragment mypageFragment;
    private com.example.supportapplication.SearchFragment searchFragment;
    private com.example.supportapplication.SupportFragment supportFragment;
    private com.example.supportapplication.MentionFragment mentionFragment;
    private com.example.supportapplication.ArticleFragment articleFragment;
    private com.example.supportapplication.SocialFragment socialFragment;
    private com.example.supportapplication.DetailFragment detailFragment;
    private com.example.supportapplication.CrowdSFragment crowdSFragment;
    private com.example.supportapplication.RegularSFragment regularSFragment;
    private com.example.supportapplication.GeneralSFragment generalSFragment;
    private com.example.supportapplication.KeywordSFragment keywordSFragment;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()){
                    case R.id.home:
                        onFragmentChange(0);
                        break;
                    case R.id.search:
                        onFragmentChange(1);
                        break;
                    case R.id.favorite:
                        onFragmentChange(2);
                        break;
                    case R.id.myPage:
                        onFragmentChange(3);
                        break;
                }
                return true;
            }
        });







        favoriteFragment = new com.example.supportapplication.FavoriteFragment();
        homeFragment = new com.example.supportapplication.HomeFragment();
        mypageFragment = new com.example.supportapplication.MypageFragment();
        searchFragment = new com.example.supportapplication.SearchFragment();


        supportFragment = new SupportFragment();
        mentionFragment = new MentionFragment();
        articleFragment = new ArticleFragment();
        socialFragment = new SocialFragment();
        detailFragment = new DetailFragment();

        crowdSFragment = new CrowdSFragment();
        keywordSFragment = new KeywordSFragment();
        regularSFragment = new RegularSFragment();
        generalSFragment = new GeneralSFragment();


        onFragmentChange(0); //첫 프래그먼트 화면을 무엇으로 지정해줄 것인지 선택














    }


    //프래그먼트 교체
    public void onFragmentChange(int index){
        if(index==0){//홈화면
            getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, homeFragment).commit();
        }else if(index==1){//검색화면
            getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, searchFragment).commit();
        }else if(index==2){//관심사화면
            getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, favoriteFragment).commit();
        }else if(index==3){//마이페이지
            getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, mypageFragment).commit();
        }else if(index==4){//명언 선택 화면
            getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, mentionFragment).commit();
        }else if(index==5){//후원처 상세 정보 화면
            getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, detailFragment).commit();
        }else if(index==6){//기사 선택 화면
            getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, articleFragment).commit();
        }else if(index==7){//소셜 선택 화면
            getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, socialFragment).commit();
        }else if(index==8){//후원 선택 화면
            getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, supportFragment).commit();
        }else if(index==9){//일반 후원 화면
            getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, generalSFragment).commit();
        }else if(index==10){//정기 후원 화면
            getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, regularSFragment).commit();
        }else if(index==11){//키워드 후원 화면
            getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, keywordSFragment).commit();
        }else if(index==12){//크라우드 후원 화면
            getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, crowdSFragment).commit();
        }
    }


}