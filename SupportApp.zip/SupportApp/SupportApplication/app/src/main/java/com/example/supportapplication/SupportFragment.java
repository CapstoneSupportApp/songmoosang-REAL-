package com.example.supportapplication;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class SupportFragment extends Fragment{

    MainActivity activity;

    @Override
    public void onAttach(Context context){
        super.onAttach(context);

        activity = (MainActivity) getActivity();
    }

    @Override
    public void onDetach(){
        super.onDetach();

        activity = null;
    }

    private View view;

    @Nullable
    @Override

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState){
        view = inflater.inflate(R.layout.fragment_support, container, false );

        Button generalbtn = (Button) view.findViewById(R.id.general);
        generalbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activity.onFragmentChange(9);
            }
        });

        Button regularbtn = (Button) view.findViewById(R.id.regular);
        regularbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activity.onFragmentChange(10);
            }
        });

        Button keywordbtn = (Button) view.findViewById(R.id.keyword);
        keywordbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activity.onFragmentChange(11);
            }
        });

        Button crowdbtn = (Button) view.findViewById(R.id.crowd);
        crowdbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activity.onFragmentChange(12);
            }
        });


        return view;

    }
}