package com.example.supportapplication;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import android.view.LayoutInflater;

import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class HomeFragment extends Fragment{

    MainActivity activity;

    @Override
    public void onAttach(Context context){
        super.onAttach(context);

        activity = (MainActivity) getActivity();
    }

    @Override
    public void onDetach(){
        super.onDetach();

        activity = null;
    }




    private View view;

    @Nullable
    @Override

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState){
        view = inflater.inflate(R.layout.fragment_home, container, false);

        ImageView btnmention1 = (ImageView) view.findViewById(R.id.today_person);
        TextView btnmention2 = (TextView) view.findViewById(R.id.today_mention);
        TextView btnmention3 = (TextView) view.findViewById(R.id.today_name);

        btnmention1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activity.onFragmentChange(4);
            }
        });

        btnmention2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activity.onFragmentChange(4);
            }
        });

        btnmention3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activity.onFragmentChange(4);
            }
        });

        TextView btnarticle1 = (TextView) view.findViewById(R.id.article_1_content);
        ImageView btnarticle2 = (ImageView) view.findViewById(R.id.article_1_image);
        TextView btnarticle3 = (TextView) view.findViewById(R.id.article_1_title);

        btnarticle1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activity.onFragmentChange(6);
            }
        });

        btnarticle2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activity.onFragmentChange(6);
            }
        });

        btnarticle3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activity.onFragmentChange(6);
            }
        });

        ImageView btnsocial = (ImageView) view.findViewById(R.id.imageList_1);

        btnsocial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activity.onFragmentChange(7);
            }
        });

        return view;

    }


}